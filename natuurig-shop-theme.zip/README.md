
# Natuurig Shopify Theme (Craft-based)

Dit is het aangepaste thema voor de dropshipping webshop **Natuurig.nl**.

## 📦 Inhoud
- Volledige layout voor home, collectie & producten
- Secties en instellingen geoptimaliseerd voor duurzaamheid
- Logo toegevoegd (natuurig-logo.png)
- Klaar om te koppelen met Shopify via GitHub

## 🔗 Shopify koppelen
1. Upload deze bestanden naar je GitHub-repo (natuurig-shop)
2. Ga in Shopify naar: Onlinewinkel > Thema's > Meer > Koppel met GitHub
3. Selecteer deze repository. Shopify importeert automatisch het thema.
